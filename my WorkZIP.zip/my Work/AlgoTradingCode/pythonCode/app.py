import quantanly

cl_price.plot(subplot=True)
plt.show()  